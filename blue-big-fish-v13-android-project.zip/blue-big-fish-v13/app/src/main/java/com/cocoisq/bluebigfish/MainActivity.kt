package com.cocoisq.bluebigfish

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        web.setBackgroundColor(0xFFEDF3FF.toInt())
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(GameBridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class GameBridge {
        @JavascriptInterface fun getCount(): Int = SharedGame.count(this@MainActivity)
        @JavascriptInterface fun recordTap(): Int {
            val count = SharedGame.tap(this@MainActivity)
            FishWidgetProvider.refreshAll(this@MainActivity)
            return count
        }
    }
}
