package com.cocoisq.bluebigfish

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import kotlin.random.Random

class FishWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it, null, false) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TAP -> {
                val count = SharedGame.tap(context)
                val phrases = arrayOf("好了", "不要點了", "幹嘛", "啊", "哦鯨鯨")
                val phrase = phrases[Random.nextInt(phrases.size)]
                playSqueak(context)
                refreshAll(context, phrase, true)
                Handler(Looper.getMainLooper()).postDelayed({ refreshAll(context, null, false) }, 1000)
                Handler(Looper.getMainLooper()).postDelayed({ refreshAll(context, phrase, false, count) }, 180)
            }
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> refreshAll(context)
        }
    }

    companion object {
        const val ACTION_TAP = "com.cocoisq.bluebigfish.WIDGET_TAP"
        private val handler = Handler(Looper.getMainLooper())

        fun refreshAll(context: Context, phrase: String? = null, squish: Boolean = false, countOverride: Int? = null) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, FishWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it, phrase, squish, countOverride) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int, phrase: String?, squish: Boolean, countOverride: Int? = null) {
            val views = RemoteViews(context.packageName, R.layout.fish_widget)
            val count = countOverride ?: SharedGame.count(context)
            views.setTextViewText(R.id.widget_count, "被戳了 ${count} 次")
            views.setTextViewText(R.id.widget_phrase, phrase ?: "")
            views.setViewVisibility(R.id.widget_phrase, if (phrase.isNullOrEmpty()) android.view.View.GONE else android.view.View.VISIBLE)
            val image = BitmapFactory.decodeResource(context.resources, R.drawable.maid_widget)
            if (squish) views.setImageViewBitmap(R.id.widget_maid, squash(image))
            else views.setImageViewResource(R.id.widget_maid, R.drawable.maid_widget)
            val tapIntent = Intent(context, FishWidgetProvider::class.java).setAction(ACTION_TAP)
            val pending = PendingIntent.getBroadcast(context, id, tapIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_maid, pending)
            manager.updateAppWidget(id, views)
        }

        private fun squash(source: Bitmap): Bitmap {
            val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.save()
            canvas.scale(1.06f, 0.82f, source.width / 2f, source.height * 0.78f)
            canvas.drawBitmap(source, 0f, 0f, paint)
            canvas.restore()
            return out
        }

        private fun playSqueak(context: Context) {
            try {
                val player = MediaPlayer.create(context, R.raw.squeak) ?: return
                player.setOnCompletionListener { it.release() }
                player.start()
            } catch (_: Exception) { }
        }
    }
}
