package com.cocoisq.bluebigfish

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SharedGame {
    private const val PREFS = "blue_big_fish_game"
    private const val KEY_COUNT = "count"
    private const val KEY_DAY = "day"
    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    @Synchronized fun count(context: Context): Int {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (p.getString(KEY_DAY, "") != today()) {
            p.edit().putString(KEY_DAY, today()).putInt(KEY_COUNT, 0).apply()
            return 0
        }
        return p.getInt(KEY_COUNT, 0)
    }

    @Synchronized fun tap(context: Context): Int {
        val next = count(context) + 1
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_DAY, today()).putInt(KEY_COUNT, next).apply()
        return next
    }
}
